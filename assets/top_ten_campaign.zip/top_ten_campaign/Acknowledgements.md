# Acknowledgements

Thanks to Sabrina Colombo for all her help with the graphics and to Zuhal Vargun for reviewing the content of the posters.

Thanks also to the OWASP Top Ten team including: 

- Neil Smithline
- Brian Glas
- Torsten Gigler
- Andrew van der Stock
- Orange Tsai

for their content which is quoted and referrenced in the Top Ten Campaign.